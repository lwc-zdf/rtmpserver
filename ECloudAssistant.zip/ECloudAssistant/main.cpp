﻿#include "RtmpPushManager.h"
#include "ECloudAssistant.h"
#include <QApplication>
#include "PullerWgt.h"
#ifdef Q_OS_WIN
#include <windows.h> // 仅限 Windows 平台
#endif


int main(int argc, char *argv[])
{
    #ifdef Q_OS_WIN
    SetConsoleOutputCP(CP_UTF8); // 必须放在创建 QApplication 之前！
    #endif

    QApplication a(argc, argv);
    ECloudAssistant w;
    w.show();
//    EventLoop loop(2);
//    PullerWgt w(nullptr);
//    w.Open("rtmp://192.168.153.133:1935/live/01");
//    w.show();
//    RtmpPushManager push;
//    push.Open("rtmp://192.168.153.133:1935/live/01");
    return a.exec();
}
