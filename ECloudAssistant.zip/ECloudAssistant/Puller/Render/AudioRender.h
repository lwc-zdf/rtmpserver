﻿#ifndef AUDIO_RENDER_H
#define AUDIO_RENDER_H

#include <QAudioSink>
#include <QAudioFormat>
#include <QMediaDevices>
#include <QIODevice>
#include "AV_Common.h"

class AudioRender
{
public:
    AudioRender();
    ~AudioRender();

    bool InitAudio(int nChannels, int sampleRate, int nSampleSize);
    void Write(AVFramePtr frame);
    int AvailableBytes();

    inline bool IsInit() const { return is_initialized_; }

private:
    bool          is_initialized_ = false;
    int           sampleSize_     = -1;
    int           volume_         = 50;  // 取值 0~100

    QAudioFormat  audioFmt_;
    QAudioSink*   audioSink_      = nullptr;
    QIODevice*    device_         = nullptr;
};

#endif
