﻿#include "AudioRender.h"
#include <QDebug>

AudioRender::AudioRender()
{
    // 设置一些默认值，后面 InitAudio 时会覆盖
    audioFmt_.setSampleRate(44100);
    audioFmt_.setChannelCount(2);
    audioFmt_.setSampleFormat(QAudioFormat::Int16);
}

AudioRender::~AudioRender()
{
    // 收尾工作
    if (device_) {
        device_->close();
        device_ = nullptr;
    }
    if (audioSink_) {
        delete audioSink_;
        audioSink_ = nullptr;
    }
}

bool AudioRender::InitAudio(int nChannels, int sampleRate, int nSampleSize)
{
    if (is_initialized_) {
        // 已经初始化过，直接返回
        return true;
    }

    sampleSize_ = nSampleSize;

    // 设置音频格式
    audioFmt_.setChannelCount(nChannels);
    audioFmt_.setSampleRate(sampleRate);

    // 根据位深选择合适的采样格式
    switch (sampleSize_) {
    case 8:
        audioFmt_.setSampleFormat(QAudioFormat::UInt8);
        break;
    case 16:
        audioFmt_.setSampleFormat(QAudioFormat::Int16);
        break;
    case 32:
        // 如果是 32 位整型，请使用 Int32；若实际是 32 位浮点，请用 Float
        audioFmt_.setSampleFormat(QAudioFormat::Int32);
        break;
    default:
        qDebug() << "[AudioRender] Unsupported sample size:" << sampleSize_;
        audioFmt_.setSampleFormat(QAudioFormat::Unknown);
        return false;
    }

    if (!audioFmt_.isValid()) {
        qDebug() << "[AudioRender] Invalid audio format!";
        return false;
    }

    // 创建 QAudioSink（播放设备 + 音频格式）
    audioSink_ = new QAudioSink(QMediaDevices::defaultAudioOutput(), audioFmt_);
    if (!audioSink_) {
        qDebug() << "[AudioRender] Failed to create QAudioSink!";
        return false;
    }

    // 设置音量（0.0 ~ 1.0）
    audioSink_->setVolume(volume_ / 100.0);

    // 开始播放，返回一个 QIODevice 用来写入 PCM 数据
    device_ = audioSink_->start();
    if (!device_) {
        qDebug() << "[AudioRender] Failed to start QAudioSink!";
        delete audioSink_;
        audioSink_ = nullptr;
        return false;
    }

    is_initialized_ = true;
    return true;
}

void AudioRender::Write(AVFramePtr frame)
{
    if (!is_initialized_ || !audioSink_ || !device_ || sampleSize_ == -1) {
        qDebug() << "[AudioRender] Audio sink is not initialized or invalid data.";
        return;
    }

    // 计算 PCM 数据大小
    int dataSize = frame->nb_samples * frame->channels * (sampleSize_ / 8);
    QByteArray audioData(reinterpret_cast<char*>(frame->data[0]), dataSize);

    // 写入到 QIODevice（音频流）
    device_->write(audioData.constData(), audioData.size());

    // 释放音频帧
    av_frame_unref(frame.get());
}
